//this appends value in the table
function drawRow(rowData) {
    var row = $("<tr />")
    $("#weather-table").append(row); //this will append tr element to table... keep its reference for a while since we will add cells into it
    row.append($("<td>" + rowData.name + "</td>"));
    row.append($("<td>" + "Lat: "+ rowData.coord.lat + "  " + "Lon: "+ rowData.coord.lon+"</td>").addClass('hidelocation'));
    row.append($("<td>" + toCelcius(rowData.main.temp)+"°C" + "</td>"));
    row.append($("<td>" + rowData.wind.speed +" m/sec"+ "</td>"));
}
//default temp value is in Kelvin, this converts it to celcius
var toCelcius = function(inKelvin) {
    var inK = inKelvin;
    return inCelcius = Math.round(inK -273.15);
}