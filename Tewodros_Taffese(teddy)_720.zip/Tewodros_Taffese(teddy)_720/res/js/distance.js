// toRad and calculateDistance were pre existent
var ascen = true;
function toRad(Value) {
    return Value * Math.PI / 180;
}

//reduced the parameter since we always compare with respect to Helsinki center, whose value is fixed
function calculateDistance(lat1, lon1) {
    var R = 6371; // km
    var lat2 = latLongEnum.helsinkiLat;
    var lon2 = latLongEnum.helsinkiLong;
    var dLat = toRad(lat2-lat1);
    var dLon = toRad(lon2-lon1);
    var lat1 = toRad(lat1);
    var lat2 = toRad(lat2);

    var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(lat1) * Math.cos(lat2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    var d = R * c;
    return d;
}

var getDistance = function () {

    //loops through the array, calls calculateDistance for distance calculation, and assins the value to a 'distance' object it creats in the tempArray
    for ( i = 0; i < tempArray.length; i++) {

        tempArray[i]["distance"] = calculateDistance(tempArray[i].coord.lat,tempArray[i].coord.lon);

    }

    //sorts by distance
    if(ascen){
        ascen = false;
        return tempArray.sort(function(a, b) {
            return a.distance - b.distance;
        });

    }
    else {
        ascen = false;
        return tempArray.sort(function(a, b) {
            return a.distance - b.distance;
        }).reverse();

    } //ends here
    //return tempArray.sort(function(a, b) {
      //  return a.distance - b.distance;
    //});
}

//this function is called onClick at location. calls the getDistance sorted array and calls drawRow function to append to HTML
var sortByDistance = function() {
    var arr = getDistance();

    $('#weather-table tbody > tr').empty();

    $.each(arr, function( index, value ) {
         drawRow(arr[index]);
    });

}
