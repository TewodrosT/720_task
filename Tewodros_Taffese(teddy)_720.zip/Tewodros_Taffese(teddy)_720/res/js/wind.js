//checks if the order is ascending and sorts it. not ascending by default
var ascen = true;
var getWind = function () {

    if(ascen){
        ascen = false;
        //sort function compares the values and puts them in ascending order
        return tempArray.sort(function(obj1, obj2) {
            return obj1.wind.speed - obj2.wind.speed;
        });

    }
    else {
        ascen = false;
        return tempArray.sort(function(obj1, obj2) {
            return obj1.wind.speed - obj2.wind.speed;
        }).reverse();

    }
}

//this function is called onClick at wind header. calls the getWind sorted array and calls drawRow function to append to HTML
var sortByWindSpeed = function () {

    var arr = getWind();
    $('#weather-table tbody > tr').empty();
    $.each(arr, function( index, value ) {
        //console.log(arr[index].wind);
        drawRow(arr[index]);
    });
}
