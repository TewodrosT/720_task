// Get weather data from the API in JSON format.. &appid=0b96668615bb92609290fa424719a2ea
var tempArray=[];
var myEnum = {'wind':1, 'temp':2};
var latLongEnum=  {'helsinkiLat':60.169847, 'helsinkiLong':24.938340};
var getWeatherData = function() {
    $('#errorMessage').hide();
    $('#weather-table tbody > tr').empty();

    var apiUrl='http://api.openweathermap.org/data/2.5/find?lat=';
    var limitCities=30; //city limits to retrieve at ones, cnt value

    $.ajax({

        //send request and complete confirmations on console
        beforeSend : function() {
            console.log('sending request');
            $('#message').show(); //shows the loading message
        },
        complete : function() {
            console.log('request complete');
            $('#message').hide();//hides the loading message
        },

        type : "GET",
        cache : false,
        dataType : "json",
        url : apiUrl+latLongEnum.helsinkiLat+"&lon="+latLongEnum.helsinkiLong+"&appid=0b96668615bb92609290fa424719a2ea"+"&cnt="+limitCities, //appended url with helsinki lat and lon values

        success : function(data) {
            //console.log( data.list);

            //stores the retrieved data from the api in a tenoArray
            $.each(data.list, function( index, value ) {
                tempArray.push(data.list[index]);
            });

           sortDataByAlphabet(data); //calls for sort data by alphabet function to sort table ascending by city name default

        },

        //error case, table is removes and error message is displayed
        error : function() {
            //console.log('error');
            $('#weather-table thead').remove() //removes the table
             $('#errorMessage').show(); //show the error message, captioned in index html
        }
    });

}
$(document).ready(function(){
    $(".nav-toggle").click(function() {
        $("nav").toggleClass("opened");
        return false;
    });
    getWeatherData(); //when document is ready, it calls for getWeatherData,  where everything happens :)
   });






