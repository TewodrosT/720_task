//sorts data in ascending order by city name
var sortDataByAlphabet = function(data) {
    //calls for sorAscending to sort data based on 'name' property, and calls drawRow to append to HTML
    $.each(data.list.sort(sortAscending("name")), function( index, value ) {
        drawRow(data.list[index]);
    });

}
//sorts data by name ascending
function sortAscending(property) {
    var sortOrder = 1;
    if(property[0] === "-") {
        sortOrder = -1;
        property = property.substr(1);
    }
    return function (a,b) {
        var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
        return result * sortOrder;
    }
}
