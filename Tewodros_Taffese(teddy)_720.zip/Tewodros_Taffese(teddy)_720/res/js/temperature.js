//checks if the order is ascending and sorts it. not ascending by default
var ascen = true;
var getTemp = function () {
    //checks if the order is ascending and sorts it. not ascending by default
    if(ascen){
        ascen = false;
        return tempArray.sort(function(obj1, obj2) {
            return obj1.main.temp - obj2.main.temp;
        });

    }
    else {
        ascen = false;
        return tempArray.sort(function(obj1, obj2) {
            return obj1.main.temp - obj2.main.temp;
        }).reverse();

    }

}

//this function is called onClick at Temperature. calls the getTemp sorted array and calls drawRow function to append to HTML
var sortByTemperature = function () {
    var arr = getTemp();

    $('#weather-table tbody > tr').empty(); //clear the table of the previous state and draw the new sorted table
    $.each(arr, function( index, value ) {
        //console.log(arr[index].main);
        drawRow(arr[index]);
    });

}
